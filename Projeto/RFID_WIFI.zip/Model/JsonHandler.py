import json


class JsonHandler:

  def __init__(self, filename):
    self.filename = filename

  def read_json(self):
    with open(self.filename, 'r') as file:
      return json.load(file)

  def write_json(self, data):
    with open(self.filename, 'w') as file:
      json.dump(data, file)

  def update_json(self, key, value):
    data = self.read_json()
    data[key] = value
    self.write_json(data)

from flask import Flask, render_template, request
#from Model.JsonHandler import JsonHandler as JH
from datetime import datetime
from pytz import timezone
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key='aceleraDaDepressao'
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///easyinout.sqlite3"

db = SQLAlchemy(app)

class registro(db.Model):  
  id=db.Column(db.Integer, primary_key=True, autoincrement=True)
  rfid=db.Column(db.String(8))
  dtHr=db.Column(db.String(150))

  def create(self, rfid, dtHr):
    self.rfid = rfid
    self.dtHr=dtHr

@app.route('/')
def main():
  return render_template('index.html')

@app.route('/rfid_read/<rfid>', methods=['GET', 'POST'])
def rfid_read(rfid):
  sao_paulo = timezone('America/Sao_Paulo')
  now = datetime.now(sao_paulo)
  # jsonHandler = JH("./Model/data.json")

  # json = jsonHandler.read_json()

  # if json["ola"][0] == rfid:
  #   return "0"
  # else:
  current_time = now.strftime("%m/%d/%Y %H:%M:%S")
    # json["ola"] = [rfid, current_time]
    # jsonHandler.write_json(json)

  reg=registro()
  reg.create(rfid,current_time)
  db.session.add(reg) 
  db.session.commit()
    
  return "1"

@app.route('/lista')
def lista():
  return render_template('lista.html', registros=registro.query.paginate(page=request.args.get('page',1,type=int), per_page=100))

if __name__ == '__main__':
  app.app_context().push()
  db.create_all()
  app.run(debug=True, host='0.0.0.0', port=81)

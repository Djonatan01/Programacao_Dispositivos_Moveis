//nome da rede a ser utilizada
//#define SECRET_SSID "DIEGO"
//Senha da rede
//#define SECRET_password  "@1c14A6CA6"

////nome da rede a ser utilizada
#define SECRET_SSID "mariah"
////Senha da rede
#define SECRET_password  "mariah2012"

//nome da rede a ser utilizada
//#define SECRET_SSID "Redmi Note 8 Pro"
//Senha da rede
//#define SECRET_password  "batata1234"
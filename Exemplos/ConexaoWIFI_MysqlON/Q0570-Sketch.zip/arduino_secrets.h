#define SECRET_SSID "***"
#define SECRET_PASS "***"

#define SECRET_USERDB "***"
#define SECRET_PASSDB "***"
